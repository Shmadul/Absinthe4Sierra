# Patched By @shmadul 2017
# Added 10.11-10.12+ support
# Fixed Crashing Issue Caused by incompatible Binary